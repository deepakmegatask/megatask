<?php $this->load->view('header');?>


<?php $this->load->view($file); ?>

<?php $this->load->view('footer');?>