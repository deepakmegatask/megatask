﻿        <!-- TESTIMONIAL
        ================================================== -->
        <section class="bg-img cover-background" data-background="<?php echo base_url()?>assets/img/bg/bg-05.png">
            <div class="container">
                <div class="section-heading mb-2-3 mb-lg-2-9 wow fadeInDown" data-wow-delay=".2s">
                    <h6 class="text-secondary"><span>Client’s love</span></h6>
                    <h2 class="mb-0 h1">Words from our clients</h2>
                </div>
                <div class="testimonial-carousel owl-carousel owl-theme wow fadeInUp" data-wow-delay=".2s">
                    <div class="testimonial-wrapper pink">
                        <div class="testimonial-quote pink"></div>
                        <div class="testimonial-image">
                            <img src="<?php echo base_url()?>assets/img/avatar/avatar-01.jpg" alt="...">
                        </div>
                        <p class="mb-3">A fulfilled client is one who will keep on purchasing from you, rarely look around, allude different clients and by and large be a whiz advocate for your business.</p>
                        <h4 class="h5 mb-1">Christy Stapleton</h4>
                        <p class="mb-0">Computer Programmer</p>
                    </div>
                    <div class="testimonial-wrapper purple">
                        <div class="testimonial-quote purple"></div>
                        <div class="testimonial-image">
                            <img src="<?php echo base_url()?>assets/img/avatar/avatar-02.jpg" alt="...">
                        </div>
                        <p class="mb-3">Doing an amazing job includes making clients "feel extraordinary" and assisting them with excursion when it may not make sense. Quality is recalled long after the cost is failed to remember.</p>
                        <h4 class="h5 mb-1">Jens Ostergaard</h4>
                        <p class="mb-0">Mainframe Programmer</p>
                    </div>
                    <div class="testimonial-wrapper blue">
                        <div class="testimonial-quote blue"></div>
                        <div class="testimonial-image">
                            <img src="<?php echo base_url()?>assets/img/avatar/avatar-03.jpg" alt="...">
                        </div>
                        <p class="mb-3">Understand what your clients need most and what your organization does best. Zero in on where those two meet. The client's discernment is your world.</p>
                        <h4 class="h5 mb-1">Mubin Bazzi</h4>
                        <p class="mb-0">Systems Programmer</p>
                    </div>
                    <div class="testimonial-wrapper yellow">
                        <div class="testimonial-quote yellow"></div>
                        <div class="testimonial-image">
                            <img src="<?php echo base_url()?>assets/img/avatar/avatar-04.jpg" alt="...">
                        </div>
                        <p class="mb-3">We consider our to be as welcomed visitors to a gathering, and we are the hosts. It's our work each day to make each significant part of the client experience somewhat better.</p>
                        <h4 class="h5 mb-1">Cecilie Fleischer</h4>
                        <p class="mb-0">Applications Programmer</p>
                    </div>
                </div>
            </div>
        </section>