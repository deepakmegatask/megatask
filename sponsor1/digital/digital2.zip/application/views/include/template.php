<?php $this->load->view('include/header');?>


<?php $this->load->view($file); ?>

<?php $this->load->view('include/footer');?>