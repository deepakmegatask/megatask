<section class="top-line">
  <div class="container">
  <div class="row">
  <div class="col-md-2 fl-left">
    <ul class="list-style top_back mt-3">
      
      <li><i class="fa fa-chevron-left"></i></li>
      <li>&nbsp;&nbsp;Back to Search</li>
    </ul>



  </div>

  <div class="col-md-7 mt-1">
    <nav aria-label="breadcrumb ">
  <ol class="breadcrumb my-breadcrumb ">
    <li class="breadcrumb-item"><a href="#" class="tag">Home</a></li>
    <li class="breadcrumb-item"><a href="#" class="tag">Dubai</a></li>
    <li class="breadcrumb-item active" aria-current="page">Dubaidetails</li>
  </ol>
 </nav>


  </div>
  </div>
  </div>
</section>


<section> 
  <div class="container">
    <div class="card">
      <div class="container-fliud">
        <div class="wrapper row">
          <div class="preview col-md-8">
            
            <div class="preview-pic tab-content tab-route">
              <div class="tab-pane active" id="pic-1"><img src="http://placekitten.com/400/252" /></div>
              <div class="tab-pane" id="pic-2"><img src="http://placekitten.com/400/252" /></div>
              <div class="tab-pane" id="pic-3"><img src="http://placekitten.com/400/252" /></div>
              <div class="tab-pane" id="pic-4"><img src="http://placekitten.com/400/252" /></div>
              <div class="tab-pane" id="pic-5"><img src="http://placekitten.com/400/252" /></div>
            </div>
            <ul class="preview-thumbnail nav nav-tabs">
              <li class="active"><a data-target="#pic-1" data-toggle="tab"><img src="http://placekitten.com/200/126" /></a></li>
              <li><a data-target="#pic-2" data-toggle="tab"><img src="http://placekitten.com/200/126" /></a></li>
              <li><a data-target="#pic-3" data-toggle="tab"><img src="http://placekitten.com/200/126" /></a></li>
              <li><a data-target="#pic-4" data-toggle="tab"><img src="http://placekitten.com/200/126" /></a></li>
              <li><a data-target="#pic-5" data-toggle="tab"><img src="http://placekitten.com/200/126" /></a></li>
            </ul>
            
          </div>
          <div class="details col-md-4 text-center">
            <h2>LOGO</h2>
            <p class="my_para">Nujoum Al Kawakeb Real Estate Corporation Agent:</p>
            <p class="my_para"><strong>Contact Agent for more information.</strong></p>
            <form>
            
            <input type="tel" id="phone" name="phone" placeholder="NAME*" class="form-control agent_con"><br>
            
            <input type="tel" id="phone" name="phone" placeholder="EMAIL*" class="form-control agent_con"><br>
            
            <input type="tel" id="phone" name="phone" placeholder="PHONE*" class="form-control agent_con"><br>
            <textarea placeholder="I would like to inquire about your property Bayut - ID87463486. Please contact me at your earliest convenience." class="form-control agent_con"></textarea>
            </form>
            <div class="btn call_btn" onclick="document.getElementById('id01').style.display='block'"><i class="fa fa-phone" aria-hidden="true"></i>&nbsp;Call</div>

<div id="id01" class="modal">

  <form class="modal-content">
    <div class="modal_container">
      <div class="row">
      <div class="col-sm-12 text-center">
        <span onclick="document.getElementById('id01').style.display='none'" class="close" title="Close Modal">×</span>
        <h4><strong>Contact Us</strong></h4>


        <div class="modal_query text-center">
        <div class="row">
        <div class="col-sm-3 mt-3">
        <span class="fl-left modal_adv"><i class="fa fa-phone" aria-hidden="true"></i></span>
        </div>

         <div class="col-sm-9 mt-3 ">
         <a href="#"class="fl-left ml-4" style="font-size:20px;">+123456789</a>


            </div>
          </div>  <!-- row -->

        <div class="row row_border">
        <div class="col-sm-12 mt-3">
        <p class=" text-center quote_wp">Please quote property reference</p>
        <p class="quote_wp"><strong>Realestate - 362-Ap-R-1731</strong></p>
        <p class="text-center">when calling us.</p>
           
      </div>
      </div> <!-- row -->
      </div>
      </div>
      </div>
      </div>
      </form>
      </div>
      </div>
      </div>
      </div>
      </div>
      </div>
      </section>