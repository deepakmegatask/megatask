<!-- footer section start here  -->

<section class="my_quel">
  <div class="container-fluid">
   <div class="row">
    <div class="col-md-6 p-0">
     <div class="left_mail">
      <ul class="list-style ale_mail">
       <li class="v2"><img src="<?php echo base_url();?>assets/images/gmail.png" class="img-fluid" style="        width: 36px;opacity: 0.2; margin-left: 60px;"></li>
       <li class="text-center email_li">Email: aliizba@gmail.com</li>
      </ul>
     </div>
    </div>  

      <div class="col-md-6 p-0">
     <div class="right_mail">
      <ul class="list-style ale_mail">
       <li class="v2"><img src="<?php echo base_url();?>assets/images/customer-service.png" class="img-fluid" style="width: 36px;opacity: 0.4; margin-left: 60px;"></li>
       <li class="text-center email_li">Support: (+00)888.666.88</li>
      </ul>
     </div>
    </div>
   </div>
  </div>
</section>

<footer class="footer-bg zxcv12356879 ">
   	<div class="container wrap-container">
      <div class="row">
      	<div class="col-md-4">
          <div class="footer my_quel">
            <ul class="list-style footer_ul p-0">
             <li class="footer_details"><a href="#">Create And Account</a>
             <li class="footer_details"><a href="#">Tips for Buyers</a>
             <li class="footer_details"><a href="#">Tips for Sellers</a>
             <li class="footer_details"><a href="#">Commercial Resources</a>
             <li class="footer_details"><a href="#">Explore Canada</a>
             <li class="footer_details"><a href="#">Global Buyers</a>

         </ul>
      	</div>
       </div>


      <div class="col-md-4">
        <div class="footer my_quel">
         <ul class="list-style footer_ul p-0">
            <li class="footer_details"><a href="#">Living Room Blog</a>
            <li class="footer_details"><a href="#">About Ale-Izba</a>
            <li class="footer_details"><a href="#">About CREA</a>
            <li class="footer_details"><a href="#">Code of Ethics</a>
            <li class="footer_details"><a href="#">Ale-Izba Care</a>
            <li class="footer_details"><a href="#">Send Feedback</a>
           
         </ul>

          </div>
        </div> 

        <div class="col-md-4">
         <div class="footer my_quel">
          <ul class="list-style footer_ul p-0">
            <li class="footer_details"><a href="#">Contact Us</a>
            <li class="footer_details"><a href="#">FAQ</a>
            <li class="footer_details"><a href="#">Privacy Policy</a>
            <li class="footer_details"><a href="#">Terms of Use</a>
            <li class="footer_details"><a href="#">Sitemap</a>
           
           </ul>
         </div>
        </div>
       </div>
      </div>


    <div class="container-fluid bg_copyright">
     <div class="row">
      <div class="col-md-6 text-center">
        <p class="">© 2008 - 2021 Realestate.com</p>
      </div>

       <div class="col-md-6 text-center">
         <div class="icon-bar ">
            <a href="#" class="facebook"><i class="fa fa-facebook"></i></a>
            <a href="#" class="twitter"><i class="fa fa-twitter"></i></a>
            <a href="#" class="google"><i class="fa fa-google"></i></a>
            <a href="#" class="linkedin"><i class="fa fa-linkedin"></i></a>
            <a href="#" class="youtube"><i class="fa fa-youtube"></i></a>
          </div>
        </div>
       </div>
      </div>
    </footer>
<!-- end -->

<!-- chosen script -->
  <script src="<?php echo base_url();?>assets/js/chosen.jquery.js" type="text/javascript"></script>
  <script src="<?php echo base_url();?>assets/js/prism.js" type="text/javascript" charset="utf-8"></script>
  <script src="<?php echo base_url();?>assets/js/init.js" type="text/javascript" charset="utf-8"></script>
<!-- end -->


</body>
</html>





     