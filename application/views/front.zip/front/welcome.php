
<section>
    
<div class="container-fluid">
 <div class="row">
  <div class="col-sm-12">
       <div class="conBox" style="padding: 183px 105px;background: #efefef;">
          <h1 style="font-size: 8em;text-align: center;color: #aba6a6;">Welcome To Ale-izba</h1>
       </div>
  </div>



 </div>
</div>
</section>

